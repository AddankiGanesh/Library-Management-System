import { Loan, Book } from '../models/types';
import { getBookByIsbn, updateBookCopies } from './bookService';
import { 
  getLoans, 
  addLoan, 
  updateLoan, 
  getActiveLoanByBookAndMember,
  getMemberById 
} from './storage';

export const issueBook = (memberId: string, isbn: string): Loan | null => {
  // Check if member exists
  const member = getMemberById(memberId);
  if (!member) {
    return null;
  }
  
  // Check if book exists and has available copies
  const book = getBookByIsbn(isbn);
  if (!book || book.copiesAvailable <= 0) {
    return null;
  }
  
  // Check if the member already has an active loan for this book
  if (getActiveLoanByBookAndMember(isbn, memberId)) {
    return null;
  }
  
  // Calculate dates
  const issueDate = new Date().toISOString().split('T')[0];
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + 14); // 14 days loan period
  
  // Generate loan ID
  const loans = getLoans();
  const lastLoanId = loans.length > 0 
    ? Math.max(...loans.map(l => parseInt(l.loanId)))
    : 0;
  const newLoanId = (lastLoanId + 1).toString();
  
  const newLoan: Loan = {
    loanId: newLoanId,
    memberId,
    isbn,
    issueDate,
    dueDate: dueDate.toISOString().split('T')[0],
    returnDate: null
  };
  
  // Update book availability
  if (!updateBookCopies(isbn, 0, -1)) {
    return null;
  }
  
  // Add the loan
  addLoan(newLoan);
  
  return newLoan;
};

export const returnBook = (loanId: string): boolean => {
  const loans = getLoans();
  const loanIndex = loans.findIndex(loan => loan.loanId === loanId);
  
  if (loanIndex === -1 || loans[loanIndex].returnDate !== null) {
    return false;
  }
  
  const loan = loans[loanIndex];
  
  // Update the loan with return date
  const updatedLoan: Loan = {
    ...loan,
    returnDate: new Date().toISOString().split('T')[0]
  };
  
  // Update book availability
  if (!updateBookCopies(loan.isbn, 0, 1)) {
    return false;
  }
  
  // Update the loan
  return updateLoan(updatedLoan);
};

export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
};

export const isOverdue = (dueDate: string): boolean => {
  const today = new Date().toISOString().split('T')[0];
  return dueDate < today;
};