import { Book, Loan, Member } from '../models/types';

// Storage keys
const BOOKS_KEY = 'lms_books';
const MEMBERS_KEY = 'lms_members';
const LOANS_KEY = 'lms_loans';

// Initial data
const initialBooks: Book[] = [
  {
    isbn: '9780132350884',
    title: 'Clean Code',
    author: 'Robert C. Martin',
    copiesTotal: 5,
    copiesAvailable: 3
  },
  {
    isbn: '9780201633610',
    title: 'Design Patterns',
    author: 'Erich Gamma et al.',
    copiesTotal: 3,
    copiesAvailable: 2
  },
  {
    isbn: '9781449331818',
    title: 'Learning JavaScript Design Patterns',
    author: 'Addy Osmani',
    copiesTotal: 4,
    copiesAvailable: 4
  }
];

const initialMembers: Member[] = [
  {
    memberId: '1001',
    name: 'Ananya Singh',
    passwordHash: '$2a$10$rPiEAgQNIT1TCoQtQsQYhOadFS4JMGZf5cJ5OucUIn8MyKs8XQS4q', // 'password123'
    email: 'ananya@mail.com',
    joinDate: '2025-05-10',
    role: 'member'
  },
  {
    memberId: '2001',
    name: 'Admin Librarian',
    passwordHash: '$2a$10$rPiEAgQNIT1TCoQtQsQYhOadFS4JMGZf5cJ5OucUIn8MyKs8XQS4q', // 'password123'
    email: 'admin@library.com',
    joinDate: '2025-01-01',
    role: 'librarian'
  }
];

const initialLoans: Loan[] = [
  {
    loanId: '42',
    memberId: '1001',
    isbn: '9780132350884',
    issueDate: '2025-05-15',
    dueDate: '2025-05-29',
    returnDate: null
  }
];

// Initialize storage if empty
export const initializeStorage = (): void => {
  if (!localStorage.getItem(BOOKS_KEY)) {
    localStorage.setItem(BOOKS_KEY, JSON.stringify(initialBooks));
  }
  
  if (!localStorage.getItem(MEMBERS_KEY)) {
    localStorage.setItem(MEMBERS_KEY, JSON.stringify(initialMembers));
  }
  
  if (!localStorage.getItem(LOANS_KEY)) {
    localStorage.setItem(LOANS_KEY, JSON.stringify(initialLoans));
  }
};

// Books storage methods
export const getBooks = (): Book[] => {
  const books = localStorage.getItem(BOOKS_KEY);
  return books ? JSON.parse(books) : [];
};

export const saveBooks = (books: Book[]): void => {
  localStorage.setItem(BOOKS_KEY, JSON.stringify(books));
};

export const addBook = (book: Book): void => {
  const books = getBooks();
  books.push(book);
  saveBooks(books);
};

export const removeBook = (isbn: string): boolean => {
  const books = getBooks();
  const index = books.findIndex(book => book.isbn === isbn);
  
  if (index !== -1) {
    books.splice(index, 1);
    saveBooks(books);
    return true;
  }
  
  return false;
};

export const updateBook = (updatedBook: Book): boolean => {
  const books = getBooks();
  const index = books.findIndex(book => book.isbn === updatedBook.isbn);
  
  if (index !== -1) {
    books[index] = updatedBook;
    saveBooks(books);
    return true;
  }
  
  return false;
};

// Members storage methods
export const getMembers = (): Member[] => {
  const members = localStorage.getItem(MEMBERS_KEY);
  return members ? JSON.parse(members) : [];
};

export const saveMembers = (members: Member[]): void => {
  localStorage.setItem(MEMBERS_KEY, JSON.stringify(members));
};

export const addMember = (member: Member): void => {
  const members = getMembers();
  members.push(member);
  saveMembers(members);
};

export const getMemberByEmail = (email: string): Member | undefined => {
  const members = getMembers();
  return members.find(member => member.email === email);
};

export const getMemberById = (id: string): Member | undefined => {
  const members = getMembers();
  return members.find(member => member.memberId === id);
};

// Loans storage methods
export const getLoans = (): Loan[] => {
  const loans = localStorage.getItem(LOANS_KEY);
  return loans ? JSON.parse(loans) : [];
};

export const saveLoans = (loans: Loan[]): void => {
  localStorage.setItem(LOANS_KEY, JSON.stringify(loans));
};

export const addLoan = (loan: Loan): void => {
  const loans = getLoans();
  loans.push(loan);
  saveLoans(loans);
};

export const updateLoan = (updatedLoan: Loan): boolean => {
  const loans = getLoans();
  const index = loans.findIndex(loan => loan.loanId === updatedLoan.loanId);
  
  if (index !== -1) {
    loans[index] = updatedLoan;
    saveLoans(loans);
    return true;
  }
  
  return false;
};

export const getLoansByMemberId = (memberId: string): Loan[] => {
  const loans = getLoans();
  return loans.filter(loan => loan.memberId === memberId);
};

export const getOverdueLoans = (): Loan[] => {
  const loans = getLoans();
  const today = new Date().toISOString().split('T')[0];
  
  return loans.filter(loan => 
    loan.returnDate === null && 
    loan.dueDate < today
  );
};

export const getActiveLoanByBookAndMember = (isbn: string, memberId: string): Loan | undefined => {
  const loans = getLoans();
  return loans.find(loan => 
    loan.isbn === isbn && 
    loan.memberId === memberId && 
    loan.returnDate === null
  );
};

export const getActiveLoanByBook = (isbn: string): Loan[] => {
  const loans = getLoans();
  return loans.filter(loan => 
    loan.isbn === isbn && 
    loan.returnDate === null
  );
};