import { Member, AuthUser } from '../models/types';
import { getMembers, getMemberByEmail, addMember } from './storage';

// Auth storage key
const AUTH_USER_KEY = 'lms_auth_user';

// For demo purposes, we're using a synchronous hash check
// In a real app, you would use bcrypt.compare asynchronously
export const login = (email: string, password: string): AuthUser | null => {
  const member = getMemberByEmail(email);
  
  if (!member) {
    return null;
  }
  
  // For demo, we're checking against a known hash without actual bcrypt
  // In production, you would use: await bcrypt.compare(password, member.passwordHash)
  // This just checks if the plain password is "password123" which matches our demo hashes
  const passwordMatches = password === 'password123';
  
  if (!passwordMatches) {
    return null;
  }
  
  const authUser: AuthUser = {
    memberId: member.memberId,
    name: member.name,
    email: member.email,
    role: member.role
  };
  
  // Store auth user in localStorage
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(authUser));
  
  return authUser;
};

export const register = (
  name: string, 
  email: string, 
  password: string,
  role: 'librarian' | 'member' = 'member'
): AuthUser | null => {
  // Check if email already exists
  if (getMemberByEmail(email)) {
    return null;
  }
  
  // Generate a new member ID
  const members = getMembers();
  const lastMemberId = members.length > 0 
    ? Math.max(...members.map(m => parseInt(m.memberId)))
    : 1000;
  const newMemberId = (lastMemberId + 1).toString();
  
  // For demo purposes, we're not actually hashing the password
  // In production, you would use: const passwordHash = await bcrypt.hash(password, 10)
  const passwordHash = '$2a$10$rPiEAgQNIT1TCoQtQsQYhOadFS4JMGZf5cJ5OucUIn8MyKs8XQS4q'; // hash for 'password123'
  
  const today = new Date().toISOString().split('T')[0];
  
  const newMember: Member = {
    memberId: newMemberId,
    name,
    passwordHash,
    email,
    joinDate: today,
    role
  };
  
  addMember(newMember);
  
  const authUser: AuthUser = {
    memberId: newMember.memberId,
    name: newMember.name,
    email: newMember.email,
    role: newMember.role
  };
  
  // Store auth user in localStorage
  localStorage.setItem(AUTH_USER_KEY, JSON.stringify(authUser));
  
  return authUser;
};

export const logout = (): void => {
  localStorage.removeItem(AUTH_USER_KEY);
};

export const getCurrentUser = (): AuthUser | null => {
  const userJson = localStorage.getItem(AUTH_USER_KEY);
  return userJson ? JSON.parse(userJson) : null;
};

export const isAuthenticated = (): boolean => {
  return getCurrentUser() !== null;
};

export const isLibrarian = (): boolean => {
  const user = getCurrentUser();
  return user !== null && user.role === 'librarian';
};