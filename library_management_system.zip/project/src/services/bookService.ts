import { Book } from '../models/types';
import { getBooks, addBook, updateBook, removeBook } from './storage';

export const getBookByIsbn = (isbn: string): Book | undefined => {
  const books = getBooks();
  return books.find(book => book.isbn === isbn);
};

export const searchBooks = (query: string): Book[] => {
  if (!query.trim()) {
    return getBooks();
  }
  
  const books = getBooks();
  const normalizedQuery = query.toLowerCase().trim();
  
  return books.filter(
    book => 
      book.title.toLowerCase().includes(normalizedQuery) ||
      book.author.toLowerCase().includes(normalizedQuery) ||
      book.isbn.includes(normalizedQuery)
  );
};

export const addNewBook = (book: Book): boolean => {
  // Validate ISBN
  if (!isValidIsbn(book.isbn)) {
    return false;
  }
  
  // Check for existing book
  if (getBookByIsbn(book.isbn)) {
    return false;
  }
  
  // Validate copies
  if (book.copiesTotal < 1 || book.copiesAvailable < 0 || book.copiesAvailable > book.copiesTotal) {
    return false;
  }
  
  addBook(book);
  return true;
};

export const updateBookCopies = (isbn: string, totalChange: number, availableChange: number): boolean => {
  const book = getBookByIsbn(isbn);
  
  if (!book) {
    return false;
  }
  
  const updatedBook = {
    ...book,
    copiesTotal: book.copiesTotal + totalChange,
    copiesAvailable: book.copiesAvailable + availableChange
  };
  
  // Validate that we don't have negative copies
  if (updatedBook.copiesTotal < 0 || updatedBook.copiesAvailable < 0) {
    return false;
  }
  
  // Validate that available copies don't exceed total copies
  if (updatedBook.copiesAvailable > updatedBook.copiesTotal) {
    return false;
  }
  
  return updateBook(updatedBook);
};

export const isValidIsbn = (isbn: string): boolean => {
  // Basic ISBN-13 validation (simplified)
  return /^\d{13}$/.test(isbn);
};