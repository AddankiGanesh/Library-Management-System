export interface Book {
  isbn: string;
  title: string;
  author: string;
  copiesTotal: number;
  copiesAvailable: number;
}

export interface Member {
  memberId: string;
  name: string;
  passwordHash: string;
  email: string;
  joinDate: string;
  role: 'librarian' | 'member';
}

export interface Loan {
  loanId: string;
  memberId: string;
  isbn: string;
  issueDate: string;
  dueDate: string;
  returnDate: string | null;
}

export interface AuthUser {
  memberId: string;
  name: string;
  email: string;
  role: 'librarian' | 'member';
}