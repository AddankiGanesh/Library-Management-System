import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import LibrarianDashboard from './pages/LibrarianDashboard';
import MemberDashboard from './pages/MemberDashboard';
import { getCurrentUser, isLibrarian } from './services/auth';

// Define route guard components
const AuthRoute: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const isAuth = getCurrentUser() !== null;
  
  if (!isAuth) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
};

const LibrarianRoute: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const isAuth = getCurrentUser() !== null;
  const librarian = isLibrarian();
  
  if (!isAuth) {
    return <Navigate to="/login" />;
  }
  
  if (!librarian) {
    return <Navigate to="/" />;
  }
  
  return <>{children}</>;
};

const RoleBasedRedirect: React.FC = () => {
  const isAuth = getCurrentUser() !== null;
  const librarian = isLibrarian();
  
  if (!isAuth) {
    return <Navigate to="/login" />;
  }
  
  if (librarian) {
    return <Navigate to="/librarian" />;
  }
  
  return <Navigate to="/member" />;
};

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        
        <Route 
          path="/librarian" 
          element={
            <LibrarianRoute>
              <LibrarianDashboard />
            </LibrarianRoute>
          } 
        />
        
        <Route 
          path="/member" 
          element={
            <AuthRoute>
              <MemberDashboard />
            </AuthRoute>
          } 
        />
        
        <Route path="/" element={<RoleBasedRedirect />} />
      </Routes>
    </Router>
  );
}

export default App;