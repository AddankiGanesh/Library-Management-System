import React, { useState, useEffect } from 'react';
import { 
  BookPlus, 
  UserPlus, 
  BookUp, 
  BookDown, 
  Clock, 
  Search 
} from 'lucide-react';
import Header from '../components/Header';
import AddBookForm from '../components/AddBookForm';
import RegisterForm from '../components/RegisterForm';
import BookCard from '../components/BookCard';
import LoanItem from '../components/LoanItem';
import { Book, Loan, Member } from '../models/types';
import { getBooks, getOverdueLoans, getMembers, removeBook } from '../services/storage';
import { searchBooks, getBookByIsbn } from '../services/bookService';
import { issueBook, returnBook } from '../services/loanService';

const LibrarianDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('books');
  const [books, setBooks] = useState<Book[]>([]);
  const [overdueLoans, setOverdueLoans] = useState<Loan[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [issueFormData, setIssueFormData] = useState({ isbn: '', memberId: '' });
  const [members, setMembers] = useState<Member[]>([]);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  
  useEffect(() => {
    refreshData();
  }, [activeTab]);
  
  const refreshData = () => {
    setBooks(getBooks());
    setOverdueLoans(getOverdueLoans());
    setMembers(getMembers());
  };
  
  const handleSearch = () => {
    setBooks(searchBooks(searchQuery));
  };
  
  const handleAddBook = () => {
    refreshData();
    setActiveTab('books');
    showMessage('Book added successfully', 'success');
  };
  
  const handleRegisterMember = () => {
    refreshData();
    setActiveTab('members');
    showMessage('Member registered successfully', 'success');
  };
  
  const handleDeleteBook = (isbn: string) => {
    if (window.confirm('Are you sure you want to delete this book?')) {
      const result = removeBook(isbn);
      if (result) {
        refreshData();
        showMessage('Book deleted successfully', 'success');
      } else {
        showMessage('Failed to delete book', 'error');
      }
    }
  };
  
  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!issueFormData.isbn || !issueFormData.memberId) {
      showMessage('ISBN and Member ID are required', 'error');
      return;
    }
    
    // Check if book exists
    const book = getBookByIsbn(issueFormData.isbn);
    if (!book) {
      showMessage('Book not found', 'error');
      return;
    }
    
    // Issue book
    const result = issueBook(issueFormData.memberId, issueFormData.isbn);
    
    if (result) {
      refreshData();
      setIssueFormData({ isbn: '', memberId: '' });
      showMessage(`Book issued successfully. Due on ${result.dueDate}`, 'success');
    } else {
      showMessage('Failed to issue book. Check book availability and member ID.', 'error');
    }
  };
  
  const handleReturnLoan = (loanId: string) => {
    const result = returnBook(loanId);
    
    if (result) {
      refreshData();
      showMessage('Book returned successfully', 'success');
    } else {
      showMessage('Failed to return book', 'error');
    }
  };
  
  const showMessage = (text: string, type: 'success' | 'error') => {
    setMessage(text);
    setMessageType(type);
    
    setTimeout(() => {
      setMessage('');
    }, 5000);
  };
  
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      
      <div className="container mx-auto px-4 py-6 flex-grow">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Librarian Dashboard</h2>
        
        {message && (
          <div className={`mb-4 p-3 rounded-md ${
            messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
          }`}>
            {message}
          </div>
        )}
        
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button 
            onClick={() => setActiveTab('books')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'books' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <BookPlus size={18} className="mr-2" /> 
            Manage Books
          </button>
          
          <button 
            onClick={() => setActiveTab('members')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'members' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <UserPlus size={18} className="mr-2" /> 
            Register Members
          </button>
          
          <button 
            onClick={() => setActiveTab('issue')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'issue' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <BookDown size={18} className="mr-2" /> 
            Issue Books
          </button>
          
          <button 
            onClick={() => setActiveTab('overdue')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'overdue' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Clock size={18} className="mr-2" /> 
            Overdue Books
          </button>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          {activeTab === 'books' && (
            <div>
              <div className="flex flex-col md:flex-row gap-4 mb-6">
                <div className="md:w-1/3">
                  <AddBookForm onSuccess={handleAddBook} />
                </div>
                
                <div className="md:w-2/3">
                  <h3 className="text-xl font-bold mb-4 text-gray-800">Book Catalog</h3>
                  
                  <div className="mb-4 flex gap-2">
                    <input
                      type="text"
                      placeholder="Search by title, author or ISBN..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-grow p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      onClick={handleSearch}
                      className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition flex items-center"
                    >
                      <Search size={18} className="mr-2" />
                      Search
                    </button>
                  </div>
                  
                  <div className="space-y-3 max-h-[600px] overflow-y-auto p-2">
                    {books.length > 0 ? (
                      books.map(book => (
                        <BookCard 
                          key={book.isbn} 
                          book={book} 
                          onDelete={handleDeleteBook}
                        />
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-6">No books found</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'members' && (
            <div className="flex flex-col md:flex-row gap-4">
              <div className="md:w-1/3">
                <RegisterForm onSuccess={handleRegisterMember} allowLibrarianRole={true} />
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-xl font-bold mb-4 text-gray-800">Member Directory</h3>
                
                <div className="overflow-x-auto">
                  <table className="min-w-full bg-white border">
                    <thead>
                      <tr className="bg-gray-100 text-gray-700">
                        <th className="py-2 px-4 border text-left">ID</th>
                        <th className="py-2 px-4 border text-left">Name</th>
                        <th className="py-2 px-4 border text-left">Email</th>
                        <th className="py-2 px-4 border text-left">Join Date</th>
                        <th className="py-2 px-4 border text-left">Role</th>
                      </tr>
                    </thead>
                    <tbody>
                      {members.map(member => (
                        <tr key={member.memberId} className="border hover:bg-gray-50">
                          <td className="py-2 px-4 border">{member.memberId}</td>
                          <td className="py-2 px-4 border">{member.name}</td>
                          <td className="py-2 px-4 border">{member.email}</td>
                          <td className="py-2 px-4 border">{member.joinDate}</td>
                          <td className="py-2 px-4 border">
                            <span className={`px-2 py-1 rounded-full text-xs ${
                              member.role === 'librarian' 
                                ? 'bg-purple-100 text-purple-800' 
                                : 'bg-blue-100 text-blue-800'
                            }`}>
                              {member.role}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'issue' && (
            <div className="flex flex-col md:flex-row gap-4">
              <div className="md:w-1/3">
                <div className="bg-white p-6 rounded-lg shadow-md border">
                  <h3 className="text-xl font-bold mb-4 text-gray-800">Issue Book</h3>
                  
                  <form onSubmit={handleIssueSubmit}>
                    <div className="mb-4">
                      <label className="block text-gray-700 mb-1" htmlFor="isbn">
                        ISBN
                      </label>
                      <input
                        type="text"
                        id="isbn"
                        value={issueFormData.isbn}
                        onChange={(e) => setIssueFormData({...issueFormData, isbn: e.target.value})}
                        className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter 13-digit ISBN"
                      />
                    </div>
                    
                    <div className="mb-4">
                      <label className="block text-gray-700 mb-1" htmlFor="memberId">
                        Member ID
                      </label>
                      <input
                        type="text"
                        id="memberId"
                        value={issueFormData.memberId}
                        onChange={(e) => setIssueFormData({...issueFormData, memberId: e.target.value})}
                        className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        placeholder="Enter member ID"
                      />
                    </div>
                    
                    <button 
                      type="submit"
                      className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition flex items-center justify-center"
                    >
                      <BookDown size={18} className="mr-2" />
                      Issue Book
                    </button>
                  </form>
                </div>
              </div>
              
              <div className="md:w-2/3">
                <h3 className="text-xl font-bold mb-4 text-gray-800">Available Books</h3>
                
                <div className="space-y-3 max-h-[500px] overflow-y-auto p-2">
                  {books.filter(book => book.copiesAvailable > 0).map(book => (
                    <BookCard 
                      key={book.isbn} 
                      book={book}
                      showActions={false}
                    />
                  ))}
                </div>
              </div>
            </div>
          )}
          
          {activeTab === 'overdue' && (
            <div>
              <h3 className="text-xl font-bold mb-4 text-gray-800">Overdue Books</h3>
              
              {overdueLoans.length > 0 ? (
                <div className="space-y-3">
                  {overdueLoans.map(loan => (
                    <LoanItem 
                      key={loan.loanId} 
                      loan={loan}
                      onReturn={handleReturnLoan}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-center py-6 text-gray-500">No overdue books at this time</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LibrarianDashboard;