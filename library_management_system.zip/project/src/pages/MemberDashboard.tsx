import React, { useState, useEffect } from 'react';
import { Search, Book as BookIcon, History, BookUp } from 'lucide-react';
import Header from '../components/Header';
import BookCard from '../components/BookCard';
import LoanItem from '../components/LoanItem';
import { Book, Loan } from '../models/types';
import { searchBooks } from '../services/bookService';
import { getCurrentUser } from '../services/auth';
import { issueBook, returnBook } from '../services/loanService';
import { getLoansByMemberId } from '../services/storage';

const MemberDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState('search');
  const [searchQuery, setSearchQuery] = useState('');
  const [books, setBooks] = useState<Book[]>([]);
  const [loans, setLoans] = useState<Loan[]>([]);
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'success' | 'error'>('success');
  
  const currentUser = getCurrentUser();
  
  useEffect(() => {
    refreshData();
  }, [activeTab]);
  
  const refreshData = () => {
    const allBooks = searchBooks('');
    setBooks(allBooks);
    
    if (currentUser) {
      setLoans(getLoansByMemberId(currentUser.memberId));
    }
  };
  
  const handleSearch = () => {
    setBooks(searchBooks(searchQuery));
  };
  
  const handleBorrowBook = (isbn: string) => {
    if (!currentUser) return;
    
    const result = issueBook(currentUser.memberId, isbn);
    
    if (result) {
      refreshData();
      showMessage(`Book borrowed successfully. Due on ${result.dueDate}`, 'success');
    } else {
      showMessage('Failed to borrow book. It may not be available.', 'error');
    }
  };
  
  const handleReturnBook = (loanId: string) => {
    const result = returnBook(loanId);
    
    if (result) {
      refreshData();
      showMessage('Book returned successfully', 'success');
    } else {
      showMessage('Failed to return book', 'error');
    }
  };
  
  const showMessage = (text: string, type: 'success' | 'error') => {
    setMessage(text);
    setMessageType(type);
    
    setTimeout(() => {
      setMessage('');
    }, 5000);
  };
  
  const activeLoans = loans.filter(loan => loan.returnDate === null);
  const loanHistory = loans.filter(loan => loan.returnDate !== null);
  
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <Header />
      
      <div className="container mx-auto px-4 py-6 flex-grow">
        <h2 className="text-2xl font-bold text-gray-800 mb-6">Member Dashboard</h2>
        
        {message && (
          <div className={`mb-4 p-3 rounded-md ${
            messageType === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
          }`}>
            {message}
          </div>
        )}
        
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          <button 
            onClick={() => setActiveTab('search')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'search' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Search size={18} className="mr-2" /> 
            Search Catalog
          </button>
          
          <button 
            onClick={() => setActiveTab('loans')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'loans' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <BookUp size={18} className="mr-2" /> 
            My Loans
            {activeLoans.length > 0 && (
              <span className="ml-2 bg-amber-500 text-white text-xs px-2 py-0.5 rounded-full">
                {activeLoans.length}
              </span>
            )}
          </button>
          
          <button 
            onClick={() => setActiveTab('history')}
            className={`flex items-center px-4 py-2 rounded-md ${
              activeTab === 'history' 
                ? 'bg-blue-600 text-white' 
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            <History size={18} className="mr-2" /> 
            Loan History
          </button>
        </div>
        
        {/* Tab Content */}
        <div className="bg-white p-6 rounded-lg shadow-md">
          {activeTab === 'search' && (
            <div>
              <div className="mb-6">
                <h3 className="text-xl font-bold mb-4 text-gray-800">Search Book Catalog</h3>
                
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Search by title, author or ISBN..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-grow p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={handleSearch}
                    className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition flex items-center"
                  >
                    <Search size={18} className="mr-2" />
                    Search
                  </button>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {books.length > 0 ? (
                  books.map(book => (
                    <BookCard 
                      key={book.isbn} 
                      book={book} 
                      onIssue={handleBorrowBook}
                      showActions={book.copiesAvailable > 0}
                    />
                  ))
                ) : (
                  <p className="col-span-2 text-center py-6 text-gray-500">No books found</p>
                )}
              </div>
            </div>
          )}
          
          {activeTab === 'loans' && (
            <div>
              <h3 className="text-xl font-bold mb-4 text-gray-800">Current Loans</h3>
              
              {activeLoans.length > 0 ? (
                <div className="space-y-3">
                  {activeLoans.map(loan => (
                    <LoanItem 
                      key={loan.loanId} 
                      loan={loan}
                      onReturn={handleReturnBook}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-center py-6 text-gray-500">You don't have any books checked out</p>
              )}
            </div>
          )}
          
          {activeTab === 'history' && (
            <div>
              <h3 className="text-xl font-bold mb-4 text-gray-800">Loan History</h3>
              
              {loanHistory.length > 0 ? (
                <div className="space-y-3">
                  {loanHistory.map(loan => (
                    <LoanItem 
                      key={loan.loanId} 
                      loan={loan}
                    />
                  ))}
                </div>
              ) : (
                <p className="text-center py-6 text-gray-500">No loan history available</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MemberDashboard;