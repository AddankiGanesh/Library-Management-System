import React from 'react';
import { Book } from 'lucide-react';
import { Book as BookType } from '../models/types';

interface BookCardProps {
  book: BookType;
  onIssue?: (isbn: string) => void;
  onReturn?: (isbn: string) => void;
  onDelete?: (isbn: string) => void;
  showActions?: boolean;
}

const BookCard: React.FC<BookCardProps> = ({ 
  book, 
  onIssue, 
  onReturn, 
  onDelete,
  showActions = true 
}) => {
  const isAvailable = book.copiesAvailable > 0;
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200 hover:shadow-lg transition duration-200">
      <div className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Book size={24} className="text-blue-700" />
            </div>
            <div>
              <h3 className="font-bold text-lg text-gray-800 line-clamp-1">{book.title}</h3>
              <p className="text-gray-600">{book.author}</p>
            </div>
          </div>
        </div>
        
        <div className="mt-3 flex justify-between items-center">
          <div className="text-sm">
            <p className="text-gray-500">ISBN: {book.isbn}</p>
            <p className="font-medium">
              Availability: 
              <span className={`ml-1 ${isAvailable ? 'text-green-600' : 'text-red-600'}`}>
                {book.copiesAvailable} of {book.copiesTotal}
              </span>
            </p>
          </div>
          
          {showActions && (
            <div className="space-x-2">
              {onIssue && isAvailable && (
                <button 
                  onClick={() => onIssue(book.isbn)}
                  className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 px-3 py-1 text-sm rounded transition"
                >
                  Borrow
                </button>
              )}
              
              {onReturn && (
                <button 
                  onClick={() => onReturn(book.isbn)}
                  className="bg-blue-100 text-blue-700 hover:bg-blue-200 px-3 py-1 text-sm rounded transition"
                >
                  Return
                </button>
              )}
              
              {onDelete && (
                <button 
                  onClick={() => onDelete(book.isbn)}
                  className="bg-red-100 text-red-700 hover:bg-red-200 px-3 py-1 text-sm rounded transition"
                >
                  Delete
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default BookCard;