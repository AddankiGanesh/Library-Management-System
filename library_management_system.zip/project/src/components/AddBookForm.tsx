import React, { useState } from 'react';
import { addNewBook } from '../services/bookService';

interface AddBookFormProps {
  onSuccess: () => void;
}

const AddBookForm: React.FC<AddBookFormProps> = ({ onSuccess }) => {
  const [formData, setFormData] = useState({
    isbn: '',
    title: '',
    author: '',
    copiesTotal: 1
  });
  
  const [error, setError] = useState('');
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'copiesTotal' ? parseInt(value) || 1 : value
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    // Validate
    if (!formData.isbn || !formData.title || !formData.author) {
      setError('All fields are required');
      return;
    }
    
    // Validate ISBN
    if (!/^\d{13}$/.test(formData.isbn)) {
      setError('ISBN must be a 13-digit number');
      return;
    }
    
    // Add book
    const result = addNewBook({
      ...formData,
      copiesAvailable: formData.copiesTotal
    });
    
    if (result) {
      onSuccess();
      // Reset form
      setFormData({
        isbn: '',
        title: '',
        author: '',
        copiesTotal: 1
      });
    } else {
      setError('Failed to add book. ISBN may already exist or be invalid.');
    }
  };
  
  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4 text-gray-800">Add New Book</h2>
      
      {error && (
        <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-md">
          {error}
        </div>
      )}
      
      <div className="mb-4">
        <label className="block text-gray-700 mb-1" htmlFor="isbn">
          ISBN (13 digits)
        </label>
        <input
          type="text"
          id="isbn"
          name="isbn"
          value={formData.isbn}
          onChange={handleChange}
          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="9780123456789"
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 mb-1" htmlFor="title">
          Title
        </label>
        <input
          type="text"
          id="title"
          name="title"
          value={formData.title}
          onChange={handleChange}
          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Book Title"
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 mb-1" htmlFor="author">
          Author
        </label>
        <input
          type="text"
          id="author"
          name="author"
          value={formData.author}
          onChange={handleChange}
          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="Author Name"
        />
      </div>
      
      <div className="mb-4">
        <label className="block text-gray-700 mb-1" htmlFor="copiesTotal">
          Number of Copies
        </label>
        <input
          type="number"
          id="copiesTotal"
          name="copiesTotal"
          value={formData.copiesTotal}
          onChange={handleChange}
          min="1"
          className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      
      <button 
        type="submit"
        className="w-full py-2 px-4 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 transition"
      >
        Add Book
      </button>
    </form>
  );
};

export default AddBookForm;