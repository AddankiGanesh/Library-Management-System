import React from 'react';
import { Loan, Book } from '../models/types';
import { formatDate, isOverdue } from '../services/loanService';
import { getBookByIsbn } from '../services/bookService';

interface LoanItemProps {
  loan: Loan;
  onReturn?: (loanId: string) => void;
}

const LoanItem: React.FC<LoanItemProps> = ({ loan, onReturn }) => {
  const book = getBookByIsbn(loan.isbn);
  const isActive = loan.returnDate === null;
  const overdue = isActive && isOverdue(loan.dueDate);
  
  if (!book) return null;
  
  return (
    <div className={`
      border rounded-lg p-4 mb-3 
      ${isActive ? 'border-blue-200 bg-blue-50' : 'border-gray-200 bg-gray-50'}
      ${overdue ? 'border-red-200 bg-red-50' : ''}
    `}>
      <div className="flex flex-col md:flex-row md:justify-between md:items-center">
        <div className="mb-2 md:mb-0">
          <h3 className="font-semibold text-gray-800">{book.title}</h3>
          <p className="text-sm text-gray-600">{book.author}</p>
        </div>
        
        <div className="flex flex-wrap gap-2 text-sm">
          <div className="px-2 py-1 bg-blue-100 text-blue-800 rounded">
            Issued: {formatDate(loan.issueDate)}
          </div>
          
          <div className={`px-2 py-1 rounded ${
            overdue 
              ? 'bg-red-100 text-red-800' 
              : 'bg-amber-100 text-amber-800'
          }`}>
            Due: {formatDate(loan.dueDate)}
          </div>
          
          {loan.returnDate && (
            <div className="px-2 py-1 bg-green-100 text-green-800 rounded">
              Returned: {formatDate(loan.returnDate)}
            </div>
          )}
        </div>
      </div>
      
      {isActive && onReturn && (
        <div className="mt-3 flex justify-end">
          <button 
            onClick={() => onReturn(loan.loanId)}
            className="bg-emerald-100 text-emerald-700 hover:bg-emerald-200 text-sm px-3 py-1 rounded transition"
          >
            Return Book
          </button>
        </div>
      )}
    </div>
  );
};

export default LoanItem;