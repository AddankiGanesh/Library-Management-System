import React from 'react';
import { Library } from 'lucide-react';
import { getCurrentUser, logout } from '../services/auth';
import { useNavigate } from 'react-router-dom';

const Header: React.FC = () => {
  const navigate = useNavigate();
  const currentUser = getCurrentUser();
  
  const handleLogout = () => {
    logout();
    navigate('/login');
  };
  
  return (
    <header className="bg-blue-700 text-white shadow-md">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2" onClick={() => navigate('/')} role="button">
          <Library size={28} className="text-amber-300" />
          <h1 className="text-xl md:text-2xl font-bold">LibrarySystem</h1>
        </div>
        
        {currentUser && (
          <div className="flex items-center">
            <div className="hidden md:block mr-4">
              <span className="text-sm text-blue-100">Logged in as</span>
              <span className="ml-1 font-medium">{currentUser.name}</span>
              <span className="ml-2 bg-blue-800 text-xs px-2 py-1 rounded-full">
                {currentUser.role}
              </span>
            </div>
            <button 
              onClick={handleLogout}
              className="bg-blue-800 hover:bg-blue-900 text-white px-3 py-1 rounded transition"
            >
              Logout
            </button>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;